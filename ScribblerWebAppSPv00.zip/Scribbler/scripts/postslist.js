// postslist.js
document.addEventListener('DOMContentLoaded', () => {
    const deleteButtons = document.querySelectorAll('.post-delete');
    const postOptions = document.querySelectorAll('.post-options');
    const modal = document.getElementById('delete-modal');
    const yesButton = document.getElementById('yes-btn');
    const noButton = document.getElementById('no-btn');
    let currentPost;

    deleteButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            currentPost = e.target.closest('.post');
            modal.style.display = 'block';
        });
    });

    yesButton.addEventListener('click', () => {
        if (currentPost) {
            currentPost.remove();
            closeModal();
            rearrangePosts();
        }
    });

    noButton.addEventListener('click', closeModal);

    window.onclick = (event) => {
        if (event.target == modal) {
            closeModal();
        }
    };

    postOptions.forEach(option => {
        option.addEventListener('click', () => {
            window.location.href = 'post.html';
        });
    });
});

function closeModal() {
    document.getElementById('delete-modal').style.display = 'none';
}

function rearrangePosts() {
    const postList = document.querySelector('.post-list');
    const posts = document.querySelectorAll('.post');
    postList.innerHTML = '';
    posts.forEach(post => {
        postList.appendChild(post);
    });
}
