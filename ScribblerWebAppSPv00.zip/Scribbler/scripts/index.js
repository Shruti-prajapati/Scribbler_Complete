// Function to open sign-up modal
function openSignUpModal() {
    document.getElementById('signUpModal').style.display = 'block';
}

// Function to close sign-up modal
function closeSignUpModal() {
    document.getElementById('signUpModal').style.display = 'none';
}

// Function to open sign-in modal
function openSignInModal() {
    document.getElementById('signInModal').style.display = 'block';
}

// Function to close sign-in modal
function closeSignInModal() {
    document.getElementById('signInModal').style.display = 'none';
}

// Function to switch to sign-up modal when sign-in link on sign-in modal is clicked
function switchToSignUp() {
    closeSignInModal();
    openSignUpModal();
}

// Validate Sign Up Form Entries
function validateSignUpForm() {
    const name = document.getElementById('signUpName').value;
    const username = document.getElementById('signUpUsername').value;
    const password = document.getElementById('signUpPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (!name || !username || !password || !confirmPassword) {
        alert('Please fill out this field.');
    } else {
        alert('Sign Up Successful!');
        closeSignUpModal();
    }
}    

// Validate Sign In Form Entries
function validateSignInForm() {
    const username = document.getElementById('signInUsername').value;
    const password = document.getElementById('signInPassword').value;

    if (!username || !password) {
        alert('Please fill out this field.');
    } else {
        alert('Sign In Successful!');
        closeSignInModal();
    }
}

// Function to open create-post modal
function openCreatePostModal() {
    document.getElementById('createPostModal').style.display = 'block';
}

// Function to close create-post modal
function closeCreatePostModal() {
    document.getElementById('createPostModal').style.display = 'none';
}

// Close the modal when clicking outside of the modal content
window.addEventListener('click', (event) => {
    if (event.target == signUpModal) {
        signUpModal.style.display = 'none';
    }
    if (event.target == signInModal) {
        signInModal.style.display = 'none';
    }
    if (event.target == createPostModal) {
        createPostModal.style.display = 'none';
    }
});
