// post.js
document.addEventListener('DOMContentLoaded', () => {
    const editBtn = document.getElementById('edit-btn');
    const likeBtn = document.getElementById('like-btn');
    const commentBtn = document.getElementById('comment-btn');
    const postTitle = document.getElementById('post-title');
    const postContent = document.getElementById('post-content');
    const likeStatement = document.getElementById('like-statement');
    const commentInput = document.getElementById('comment-input');
    const allComments = document.getElementById('all-comments');

    let isEditing = false;
    let likeCount = 0;

    editBtn.addEventListener('click', () => {
        if (isEditing) {
            postTitle.setAttribute('contenteditable', 'false');
            postContent.setAttribute('contenteditable', 'false');
            editBtn.innerHTML = 'Edit <i class="fas fa-edit"></i>';
            postTitle.classList.remove('editable');
            postContent.classList.remove('editable');
        } else {
            postTitle.setAttribute('contenteditable', 'true');
            postContent.setAttribute('contenteditable', 'true');
            postTitle.focus();
            editBtn.innerHTML = 'Save <i class="fas fa-save"></i>';
            postTitle.classList.add('editable');
            postContent.classList.add('editable');
        }
        // postTitle.classList.toggle('editable');
        // postContent.classList.toggle('editable');
        isEditing = !isEditing;
    });

    likeBtn.addEventListener('click', () => {
        likeCount++;
        likeBtn.innerHTML = '<i class="fas fa-thumbs-up"></i> Liked!';
        if (likeCount === 1) {
            likeStatement.textContent = '1 person likes this!';
        } else {
            likeStatement.textContent = `${likeCount} people like this!`;
        }
    });

    commentBtn.addEventListener('click', () => {
        const commentText = commentInput.value.trim();
        if (commentText !== '') {
            allComments.classList.remove('all-comments')
            const comment = document.createElement('div');
            comment.classList.add('comment');
            comment.textContent = commentText;
            allComments.insertBefore(comment, allComments.firstChild);
            commentInput.value = '';
            allComments.classList.add('all-comments')
        }
    });
});
